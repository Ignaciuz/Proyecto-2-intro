import tkinter as tk
from juego import Juego

def iniciar_escapa():
    ventana.destroy()
    Juego("escapa")

def iniciar_cazador():
    ventana.destroy()
    Juego("cazador")

def salir():
    ventana.destroy()

# Ventana del menú principal pero se supone que deberia ir en un tkinter.py (esta en discusion) por ahora es solo pruebañ
ventana = tk.Tk()
ventana.title("Seleccionar modo de juego")
ventana.geometry("500x400")
ventana.configure(bg="#f0f4f8")

titulo = tk.Label(ventana,text="Seleccione un modo de juego",font=("Helvetica", 20, "bold"),bg="#f0f4f8",fg="#2c3e50")
titulo.pack(pady=40)

btn1 = tk.Button(ventana, text="Modo Escapa",font=("Helvetica", 16), bg="#5dade2", fg="white",width=20, height=2, command=iniciar_escapa)
btn1.pack(pady=20)

btn2 = tk.Button(ventana, text="Modo Cazador",font=("Helvetica", 16), bg="#5dade2", fg="white",width=20, height=2, command=iniciar_cazador)
btn2.pack(pady=20)

btn3 = tk.Button(ventana, text="Salir",font=("Helvetica", 16), bg="#c0392b", fg="white",width=20, height=2, command=salir)
btn3.pack(pady=20)

ventana.mainloop()
