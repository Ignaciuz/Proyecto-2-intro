import tkinter as tk
from mapa import Mapa

class Juego:
    def __init__(self, modo):
        self.modo = modo

        print("Modo seleccionado:", self.modo)

        #SE SUPONE QUE TK MATTERS VA EN TK.PY (VEREMOS)
        #Ventana principal
        self.ventana = tk.Tk()
        self.ventana.title("Escapa del Laberinto")
        self.ventana.geometry("700x700")
        self.ventana.configure(bg="#f0f4f8")

        #Canvas donde se dibuja todo
        self.canvas = tk.Canvas(self.ventana, width=600, height=600, bg="white")
        self.canvas.pack(pady=40)

        #Mapa
        self.mapa = Mapa(10, 10)
        self.mapa.generar_mapa()

        self.tam = 60  # tamaño de cada celda del mapa

        #Jugador
        self.jugador_x = 0
        self.jugador_y = 0

        #Dibujar mapa y jugador
        self.dibujar_mapa()
        self.dibujar_jugador()

        #Capturar teclas
        self.ventana.bind("<Up>", self.arriba)
        self.ventana.bind("<Down>", self.abajo)
        self.ventana.bind("<Left>", self.izquierda)
        self.ventana.bind("<Right>", self.derecha)

        #Iniciar ventana
        self.ventana.mainloop()

#_____________________________________________________________________________
        
    #DIBUJAR MAPA COMPLETO
    def dibujar_mapa(self):
        for f in range(self.mapa.filas):
            for c in range(self.mapa.columnas):

                celda = self.mapa.matriz[f][c]
                color = celda.color  # viene de terreno.py

                x1 = c * self.tam
                y1 = f * self.tam
                x2 = x1 + self.tam
                y2 = y1 + self.tam

                self.canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="gray")

    
    #DIBUJAR JUGADOR
    def dibujar_jugador(self):
        self.canvas.delete("jugador")

        x1 = self.jugador_x * self.tam + 10
        y1 = self.jugador_y * self.tam + 10
        x2 = x1 + self.tam - 20
        y2 = y1 + self.tam - 20

        self.canvas.create_oval(x1, y1, x2, y2, fill="#3498db", tags="jugador")


    #VALIDACIÓN DEL MOVIMIENTO SEGÚN TERRENO
    def puede_moverse(self, x, y):
        casilla = self.mapa.obtener_casilla(x, y)
        if casilla is None:
            return False

        return not casilla.bloquea_jugador

    
    #MOVIMIENTO
    def arriba(self, event):
        if self.puede_moverse(self.jugador_x, self.jugador_y - 1):
            self.jugador_y -= 1
            self.dibujar_jugador()

    def abajo(self, event):
        if self.puede_moverse(self.jugador_x, self.jugador_y + 1):
            self.jugador_y += 1
            self.dibujar_jugador()

    def izquierda(self, event):
        if self.puede_moverse(self.jugador_x - 1, self.jugador_y):
            self.jugador_x -= 1
            self.dibujar_jugador()

    def derecha(self, event):
        if self.puede_moverse(self.jugador_x + 1, self.jugador_y):
            self.jugador_x += 1
            self.dibujar_jugador()
