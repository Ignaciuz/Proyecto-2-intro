import tkinter as tk
from mapa import Mapa

#________________________________________________________________________
        
class Juego:
    def __init__(self, modo):
        self.corriendo = False
        self.modo = modo
        self.energia = 100
        self.energia_max = 100
        
        print("Modo seleccionado:", self.modo)

        #_______________________________________________________________________       

        #SE SUPONE QUE TK MATTERS VA EN TK.PY (VEREMOS)
        #Ventana principal
        self.ventana = tk.Tk()
        self.ventana.title("Escapa del Laberinto")
        self.ventana.geometry("700x700")
        self.ventana.configure(bg="#f0f4f8")

        # HUD – Barra de energía fuera del canvas
        self.frame_hud = tk.Frame(self.ventana, bg="#f0f4f8")
        self.frame_hud.pack(pady=10)

        self.label_energia = tk.Label(self.frame_hud, text="Energía:", font=("Helvetica", 12))
        self.label_energia.pack(side="left", padx=5)

        self.canvas_barra = tk.Canvas(self.frame_hud, width=200, height=20, bg="lightgray")
        self.canvas_barra.pack(side="left")

        self.barra_energia = self.canvas_barra.create_rectangle(0, 0, 200, 20, fill="green")


        #Canvas donde se dibuja todo
        self.canvas = tk.Canvas(self.ventana, width=600, height=600, bg="white")
        self.canvas.pack()

    
        #Mapa
        self.mapa = Mapa(10, 10)
        self.mapa.generar_mapa()

        self.tam = 60  # tamaño de cada celda del mapa

        #Jugador
        self.jugador_x = 0
        self.jugador_y = 0

        #Dibujar mapa y jugador
        self.dibujar_mapa()
        self.dibujar_jugador()

        #Capturar teclas
        self.ventana.bind("<Up>", self.arriba)
        self.ventana.bind("<Down>", self.abajo)
        self.ventana.bind("<Left>", self.izquierda)
        self.ventana.bind("<Right>", self.derecha)

        self.ventana.bind("<KeyPress-Shift_L>", self.iniciar_correr)
        self.ventana.bind("<KeyRelease-Shift_L>", self.detener_correr)

        self.recuperar_energia()
        
        #Iniciar ventana
        self.ventana.mainloop()
       
#_____________________________________________________________________________
        
    #DIBUJAR MAPA COMPLETO
    def dibujar_mapa(self):
        for f in range(self.mapa.filas):
            for c in range(self.mapa.columnas):

                celda = self.mapa.matriz[f][c]
                color = celda.color  # viene de terreno.py

                x1 = c * self.tam
                y1 = f * self.tam
                x2 = x1 + self.tam
                y2 = y1 + self.tam

                self.canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="gray")

    
    #DIBUJAR JUGADOR
    def dibujar_jugador(self):
        self.canvas.delete("jugador")

        x1 = self.jugador_x * self.tam + 10
        y1 = self.jugador_y * self.tam + 10
        x2 = x1 + self.tam - 20
        y2 = y1 + self.tam - 20

        self.canvas.create_oval(x1, y1, x2, y2, fill="#3498db", tags="jugador")

#_________________________________________________________________________
        
    #MOVIMIENTO
        #Validacion del movimiento segun el terreno
    def puede_moverse(self, x, y):
        casilla = self.mapa.obtener_casilla(x, y)
        if casilla is None:
            return False

        return not casilla.bloquea_jugador

    
    def arriba(self, event):
        if self.puede_moverse(self.jugador_x, self.jugador_y - 1):
            if self.corriendo and self.energia > 0:
                self.jugador_y -= 2
                self.energia -= 5
            else:
                self.jugador_y -= 1

            #nunca bajar de 0
            if self.energia < 0:
                self.energia = 0

            self.actualizar_barra_energia()
            self.dibujar_jugador()
            
    def abajo(self, event):
        if self.puede_moverse(self.jugador_x, self.jugador_y + 1):
            self.jugador_y += 1
            self.dibujar_jugador()

    def izquierda(self, event):
        if self.puede_moverse(self.jugador_x - 1, self.jugador_y):
            self.jugador_x -= 1
            self.dibujar_jugador()

    def derecha(self, event):
        if self.puede_moverse(self.jugador_x + 1, self.jugador_y):
            self.jugador_x += 1
            self.dibujar_jugador()

#_________________________________________________________________________

    #ENERGÍA
    def actualizar_barra_energia(self):
        porcentaje = self.energia / self.energia_max
        ancho = 200 * porcentaje  #barra completa es 200pix

        #actualizar barra en el heads up display, NO en el mapa
        self.canvas_barra.coords(self.barra_energia, 0, 0, ancho, 20)

        #color según nivel
        if porcentaje > 0.6:
            color = "green"
        elif porcentaje > 0.3:
            color = "yellow"
        else:
            color = "red"

        self.canvas_barra.itemconfig(self.barra_energia, fill=color)


    def iniciar_correr(self, event):
        self.corriendo = True

    def detener_correr(self, event):
        self.corriendo = False

    def recuperar_energia(self):
        if not self.corriendo and self.energia < self.energia_max:
            self.energia += 1

        self.actualizar_barra_energia()
        self.ventana.after(500, self.recuperar_energia)

#_______________________________________________________________________________
