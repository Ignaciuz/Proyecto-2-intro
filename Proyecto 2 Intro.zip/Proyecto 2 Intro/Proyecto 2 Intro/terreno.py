import random

#___________________________Terreno______________________________

#e: no recibe entradas al ser una clase base sin constructor explícito
#s: define atributos genéricos de cualquier tipo de terreno (nombre, color, bloqueos)
#r: diseñada para ser heredada; sus atributos pueden ser sobrescritos por clases hijas

class TerrenoBase:
    #Clase base para todos los tipos de terrenoS
    nombre = "terreno"
    color = "white"    
    bloquea_jugador = False
    bloquea_enemigo = False
    
#e: no recibe entradas directas; hereda de TerrenoBase
#s: representa una casilla transitable para jugador y enemigo
#r: ninguno adicional; nombre, color y bloqueos deben mantenerse coherentes con el propósito del terreno

class Camino(TerrenoBase):
    nombre = "camino"
    color = "#ecf0f1"
    bloquea_jugador = False
    bloquea_enemigo = False

#e: no recibe entradas; hereda de TerrenoBase
#s: representa una casilla que bloquea tanto al jugador como a los enemigos
#r: jugadores y enemigos no pueden entrar; debe usarse cuando se requiera un obstáculo total

class Muro(TerrenoBase):
    nombre = "muro"
    color = "#2c3e50"
    bloquea_jugador = True
    bloquea_enemigo = True

#e: no recibe entradas; hereda de TerrenoBase
#s: representa una casilla que permite el paso del jugador pero bloquea a los enemigos
#r: bloquea_enemigo debe ser True; usada para crear rutas exclusivas del jugador

class Tunel(TerrenoBase):
    nombre = "tunel"
    color = "#C0C0C0"
    bloquea_jugador = False
    bloquea_enemigo = True  #solo el jugador puede entrar
    
#e: no recibe entradas; hereda de TerrenoBase
#s: casilla que bloquea al jugador pero permite el paso de los enemigos
#r: bloquea_jugador debe ser True; usada para zonas inaccesibles al jugador pero transitables para enemigos

class Liana(TerrenoBase):
    nombre = "liana"
    color = "#90EE90"
    bloquea_jugador = True   #ugador NO puede entrar
    bloquea_enemigo = False  #cazadores sí pueden entra

#e: no recibe entradas; hereda de TerrenoBase
#s: casilla especial que representa la meta del jugador en modo escapa
#r: debe ser accesible tanto para jugador como enemigos; se usa para verificar condiciones de victoria o escape


class Salida(TerrenoBase):
    nombre = "salida"
    color = "green"
    bloquea_jugador = False
    bloquea_enemigo = False
