

#e: objeto juego que contiene toda la informacion necesaria para la animacion (coord y tam) etc, frame_actual que es el número de frame de la animación
#s: no retorna nada precisamente es estrictamente grafico.
#r: -
def animacion_jugador(juego, frame_actual=0):

    #detener animación si termina el juego
    if juego.juego_terminado:
        return

    juego.canvas.delete("jugador_idle")

    #cálculo del tamaño del pulso
    pulso_base = juego.tam - 20
    fase = frame_actual % 4

    if fase == 0:
        cambio_tamaño = 0
    elif fase == 1:
        cambio_tamaño = 2
    elif fase == 2:
        change_size = 4
        cambio_tamaño = 4
    else:
        cambio_tamaño = 2

    #calcular el óvalo del efecto
    x_min = juego.jugador_x * juego.tam + 10 - cambio_tamaño
    y_min = juego.jugador_y * juego.tam + 10 - cambio_tamaño
    x_max = x_min + pulso_base + cambio_tamaño * 2
    y_max = y_min + pulso_base + cambio_tamaño * 2

    juego.canvas.create_oval(x_min, y_min, x_max, y_max, outline="#85C1E9", width=2, tags="jugador_idle")

#_________________________________________________________________


    #e: recibe juego para acceder a la ventana Tk y frame_actual para avanzar el número de frame
    #s: no retorna nada, programa una llamada futura para continuar la animación
    #r: requiere que juego.ventana exista y no haya sido destruida; frame_actual debe ser entero
    #llamar siguiente frame
    def siguiente_frame():
        animacion_jugador(juego, frame_actual + 1)

    juego.ventana.after(150, siguiente_frame)



#_________________________________________________________________
    
#   ANIMACIÓN 2 — COLOCAR TRAMPA
#_________________________________________________________________

#e: juego (objeto con canvas y tamaño de celda), trampa_x y trampa_y (coords de la trampa), frame_actual (entero del estado de animación)
#s: no retorna nada, dibuja un efecto visual de expansión en el canvas
#r: requiere que juego.canvas exista; frame_actual debe ser entero; las coordenadas deben estar dentro del mapa

def animacion_trampa(juego, trampa_x, trampa_y, frame_actual=0):

    if frame_actual > 6:
        juego.canvas.delete("trampa_anim")
        return

    juego.canvas.delete("trampa_anim")

    tamaño_base = juego.tam // 3
    tamaño_actual = tamaño_base + frame_actual * 3

    #calcular posición centrada
    x_min = trampa_x * juego.tam + (juego.tam // 2 - tamaño_actual // 2)
    y_min = trampa_y * juego.tam + (juego.tam // 2 - tamaño_actual // 2)
    x_max = x_min + tamaño_actual
    y_max = y_min + tamaño_actual

    juego.canvas.create_oval(x_min, y_min, x_max, y_max, outline="black", width=3, tags="trampa_anim")
    
    #e: recibe juego (para acceder a ventana y canvas), trampa_x y trampa_y (coordenadas de la trampa), frame_actual (entero que incrementa el avance de animación)
    #s: no retorna nada, programa la siguiente actualización de la animación
    #r: requiere que juego.ventana exista y no esté destruida; frame_actual debe ser entero

    #siguiente frame
    def siguiente_frame():
        animacion_trampa(juego, trampa_x, trampa_y, frame_actual + 1)

    juego.ventana.after(60, siguiente_frame)



#_________________________________________________________________
    
#   ANIMACIÓN 3 — DESVANECER ENEMIGO AL MORIR
#_________________________________________________________________

#e: juego (objeto con canvas y tamaño de celda), enemigo (objeto con coordenadas enemigas), frame_actual (entero que controla el avance de la animación)
#s: no retorna nada, genera en el canvas un efecto gráfico de desvanecimiento progresivo
#r: requiere que juego.canvas y juego.ventana existan; enemigo debe tener enemigo_x y enemigo_y; frame_actual debe ser entero
def animacion_desevanecer(juego, enemigo, frame_actual=0):

    if frame_actual > 6:
        #limpiar sprite final
        juego.canvas.delete(f"enemigo_fade_{id(enemigo)}")
        return

    juego.canvas.delete(f"enemigo_fade_{id(enemigo)}")

    #cálculo del nivel de opacidad (simulación con valores de rojo)
    opacidad_color = 255 - frame_actual * 40
    color_hex = f"#{opacidad_color:02x}0000"

    #posición del enemigo
    x_min = enemigo.enemigo_x * juego.tam + 10
    y_min = enemigo.enemigo_y * juego.tam + 10
    x_max = x_min + juego.tam - 20
    y_max = y_min + juego.tam - 20

    juego.canvas.create_oval(x_min, y_min, x_max, y_max, fill=color_hex, outline="", tags=f"enemigo_fade_{id(enemigo)}")

    #siguiente frame
    def siguiente_frame():
        animacion_desevanecer(juego, enemigo, frame_actual + 1)

    juego.ventana.after(70, siguiente_frame)
