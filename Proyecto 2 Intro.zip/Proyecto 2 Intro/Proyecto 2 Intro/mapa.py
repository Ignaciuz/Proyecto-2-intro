import random
from terreno import *

#______________________________Mapa______________________________

class Mapa:
#e: filas y columnas (enteros que indican el tamaño del mapa)
#s: no retorna nada, inicializa la estructura del mapa y genera la matriz vacía
#r: filas y columnas deben ser enteros positivos; crear_matriz_vacia debe estar definido en la clase

    def __init__(self, filas, columnas):
        self.filas = filas
        self.columnas = columnas
        self.matriz = []

        self.crear_matriz_vacia()   #llamada al método para crear la matriz
        
#e: usa atributos internos filas y columnas para construir la matriz
#s: no retorna nada, genera una matriz del tamaño indicado rellenada con None
#r: filas y columnas deben ser enteros positivos; matriz debe ser un atributo existente de la clase

    def crear_matriz_vacia(self):
        self.matriz = []

        for f in range(self.filas):
            fila = []

            for c in range(self.columnas):
                fila.append(None)

            self.matriz.append(fila)

#e: usa atributos internos filas, columnas y matriz; requiere acceso a las clases Muro, Camino, Salida, Tunel y Liana, así como al módulo random
#s: no retorna nada, genera un mapa completo: primero un camino principal desde (0,0), marca la salida y luego rellena el resto con terrenos aleatorios
#r: filas y columnas deben ser enteros positivos; las clases de los distintos tipos de terreno deben estar definidas; matriz debe haber sido creada previamente; el algoritmo asume que (0,0) es una posición válida

    def generar_mapa(self):
        #crear todo como muro inicialmente
        for f in range(self.filas):
            for c in range(self.columnas):
                self.matriz[f][c] = Muro()

        #generar un camino aleatorio desde (0,0)
        camino = []
        visitado = set()
        pila = [(0, 0)]

        while pila:
            x, y = pila.pop()

            if (x, y) in visitado:
                continue
            visitado.add((x, y))
            camino.append((x, y))

            #si llegamos a la última fila → fin del camino
            if y == self.filas - 1:
                break

            #movimientos posibles: derecha, izquierda, arriba, abajo
            vecinos = []
            if x + 1 < self.columnas: vecinos.append((x + 1, y))
            if x - 1 >= 0: vecinos.append((x - 1, y))
            if y + 1 < self.filas: vecinos.append((x, y + 1))
            if y - 1 >= 0: vecinos.append((x, y - 1))

            random.shuffle(vecinos)
            for nx, ny in vecinos:
                if (nx, ny) not in visitado:
                    pila.append((nx, ny))

        #marcar el camino encontrado como Camino()
        for x, y in camino:
            self.matriz[y][x] = Camino()

        #la última celda del camino es la salida
        salida_x, salida_y = camino[-1]
        self.matriz[salida_y][salida_x] = Salida()

        #rellenar el resto del mapa con terreno aleatorio
        for f in range(self.filas):
            for c in range(self.columnas):

                if isinstance(self.matriz[f][c], (Camino, Salida)):
                    continue

                opcion = random.randint(1, 4)

                if opcion == 1:
                    self.matriz[f][c] = Camino()
                elif opcion == 2:
                    self.matriz[f][c] = Muro()
                elif opcion == 3:
                    self.matriz[f][c] = Tunel()
                else:
                    self.matriz[f][c] = Liana()

#e: x y y (coordenadas a consultar)
#s: retorna la casilla ubicada en (x, y) o None si la posición está fuera del mapa
#r: x y y deben ser enteros; filas, columnas y matriz deben estar correctamente inicializados

    def obtener_casilla(self, x, y):
        if 0 <= y < self.filas and 0 <= x < self.columnas:
            return self.matriz[y][x]
        return None
    
#e: x y y (coordenadas destino del jugador), usa obtener_casilla para acceder a la celda correspondiente
#s: retorna True si la casilla existe y no bloquea al jugador; False en caso contrario
#r: x y y deben ser enteros dentro del rango del mapa; cada casilla debe poseer el atributo bloquea_jugador

    def es_camino_valido_para_jugador(self, x, y):
        #Devuelve True si el jugador puede entrar en esa casilla.
        casilla = self.obtener_casilla(x, y)
        if casilla is None:
            return False
        return not casilla.bloquea_jugador

#e: x y y (coordenadas destino del enemigo), usa obtener_casilla para acceder a la casilla correspondiente
#s: retorna True si la casilla existe y no bloquea a los enemigos; False en caso contrario
#r: x y y deben ser enteros válidos dentro del mapa; cada casilla debe tener el atributo bloquea_enemigo

    def es_camino_valido_para_enemigo(self, x, y):
        #Devuelve True si un cazador puede entrar en esa casilla.
        casilla = self.obtener_casilla(x, y)
        if casilla is None:
            return False
        return not casilla.bloquea_enemigo

#e: usa la matriz interna del objeto (self.matriz) donde cada casilla posee un atributo nombre
#s: no retorna nada, imprime en consola una representación textual del mapa usando iniciales de cada terreno
#r: matriz debe estar generada y cada casilla debe tener un atributo nombre; la función está pensada solo para depuración

    def mostrar_mapa(self):
        #Imprime el mapa en texto (para revision) #puede quitarse
        for fila in self.matriz:
            print(" ".join(t.nombre[0].upper() for t in fila))
