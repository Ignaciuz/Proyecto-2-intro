import tkinter as tk
from tkinter import messagebox
from puntajes import obtener_top5

#____________________________________________________________________

#              PANTALLA FINAL (SIN PEDIR NOMBRE)
#____________________________________________________________________

#e: stats (valores finales de la partida como modo, puntaje y métricas asociadas)
#s: no retorna nada, crea y muestra una ventana gráfica con el resumen final
#r: -

def mostrar_pantalla_final(stats):

    ventana_final = tk.Tk()
    ventana_final.title("Resumen de la Partida")
    ventana_final.geometry("420x470")
    ventana_final.resizable(False, False)

    frame = tk.Frame(ventana_final, bg="#f0f0f0")
    frame.pack(fill="both", expand=True)

    lbl_titulo = tk.Label(frame,text="RESUMEN DE LA PARTIDA",font=("Arial", 18, "bold"),bg="#f0f0f0")
    lbl_titulo.pack(pady=15)

    modo = stats.get("Modo", "").lower()

    #_________________ ESTADÍSTICAS INDIVIDUALES _________________

    if modo == "escapa":
        lista_mostrar = [
            ("Puntaje", stats.get("Puntaje", 0)),
            ("Tiempo", stats.get("Tiempo", "0")),
            ("Enemigos eliminados", stats.get("Enemigos eliminados", 0)),
            ("Trampas colocadas", stats.get("Trampas colocadas", 0))]

    elif modo == "cazador":
        lista_mostrar = [
            ("Puntaje", stats.get("Puntaje", 0)),
            ("Tiempo", stats.get("Tiempo", "0")),
            ("Enemigos cazados", stats.get("Enemigos cazados", 0)),
            ("Enemigos escapados", stats.get("Enemigos escapados", 0))]

    else:
        lista_mostrar = []

    for texto, valor in lista_mostrar:
        tk.Label(frame,text=f"{texto}: {valor}",font=("Arial", 14),bg="#f0f0f0").pack(pady=5)

    # _________________ TOP 5 _________________

    lbl_top = tk.Label(frame,text="TOP 5 — " + stats["Modo"].upper(),font=("Arial", 16, "bold"),bg="#f0f0f0")
    lbl_top.pack(pady=10)

    top = obtener_top5(stats["Modo"])

    for entrada in top:
        nombre = entrada[0]
        puntaje = entrada[1]

        tk.Label(frame,
                 text=f"{nombre}: {puntaje}",
                 font=("Arial", 14),bg="#f0f0f0").pack()


    # _________________ BOTÓN VOLVER AL MENÚ _________________

#e: no recibe parámetros directos; usa ventana_final desde el ámbito externo para cerrarla
#s: no retorna nada, destruye la ventana final y ejecuta la importación de main para volver al menú
#r: requiere que ventana_final exista; el módulo main debe estar disponible y ejecutable
    def volver_menu():
        ventana_final.destroy()
        import main  #para volver al menu principal

    btn_volver = tk.Button(frame,text="Volver al menú",font=("Arial", 14),command=volver_menu)
    btn_volver.pack(pady=15)

#____________________________________________________________________
    
#e: modo (cadena que indica el modo de juego en que ocurrió la derrota)
#s: no retorna nada, crea una ventana gráfica mostrando el mensaje de derrota
#r: requiere entorno gráfico Tk disponible; modo debe ser una cadena válida para mostrarse correctamente
def mostrar_pantalla_derrota(modo):

    ventana = tk.Tk()
    ventana.title("Fin del juego")
    ventana.geometry("350x250")
    ventana.resizable(False, False)

    frame = tk.Frame(ventana, bg="#f0f0f0")
    frame.pack(fill="both", expand=True)

    tk.Label(frame,
             text=f"Perdiste en modo {modo.upper()}",
             font=("Arial", 16, "bold"),
             bg="#f0f0f0").pack(pady=20)

    tk.Label(frame,
             text="Mejor suerte la próxima...",
             font=("Arial", 14),
             bg="#f0f0f0").pack(pady=10)
    
#e: no recibe parámetros directos; usa la variable ventana del ámbito externo para cerrarla
#s: no retorna nada, cierra la ventana de derrota y ejecuta la importación de main para regresar al menú principal
#r: requiere que ventana exista; el módulo main debe estar disponible y sin errores al importar
    def volver_menu():
        ventana.destroy()
        import main

    tk.Button(frame,
              text="Volver al menú",
              font=("Arial", 14),
              command=volver_menu).pack(pady=20)

#____________________________________________________________________

#                  INTERFAZ GRÁFICA DEL JUEGO
#____________________________________________________________________

#e: juego (objeto que recibe la interfaz creada para usarla en el ciclo del juego)
#s: retorna una tupla con (ventana, canvas, canvas_barra, barra_energia) para que el juego las utilice
#r: requiere entorno gráfico Tk; el objeto juego debe poder almacenar y usar estos elementos; tamaños y geometrías deben ser compatibles con la resolución disponible
def crear_interfaz_juego(juego):

    ventana = tk.Tk()

    #forzar foco en la ventana del juego
    ventana.focus_force()
    ventana.attributes('-topmost', True)

    ventana.title("Escapa del Laberinto")
    ventana.geometry("700x700")
    ventana.configure(bg="#f0f4f8")

    #HUD (barra superior)
    frame_hud = tk.Frame(ventana, bg="#f0f4f8")
    frame_hud.pack(pady=10)

    label_energia = tk.Label(frame_hud,text="Energía:",font=("Helvetica", 12),bg="#f0f4f8")
    label_energia.pack(side="left", padx=5)

    #barra de energía
    canvas_barra = tk.Canvas(frame_hud,width=200,height=20,bg="lightgray",highlightthickness=0)
    canvas_barra.pack(side="left")

    barra_energia = canvas_barra.create_rectangle(0, 0, 200, 20, fill="green")

    #canvas principal donde se dibuja el mapa
    canvas = tk.Canvas(ventana,width=600,height=600,bg="white")
    canvas.pack()

    return ventana, canvas, canvas_barra, barra_energia
