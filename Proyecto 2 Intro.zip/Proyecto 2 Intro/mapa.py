import random
from terreno import Camino, Muro, Tunel, Liana

#______________________________Mapa______________________________

class Mapa:
    def __init__(self, filas, columnas):
        self.filas = filas
        self.columnas = columnas
        self.matriz = []

        self.crear_matriz_vacia()   #llamada al método para crear la matriz

    def crear_matriz_vacia(self):
        self.matriz = []

        for f in range(self.filas):
            fila = []

            for c in range(self.columnas):
                fila.append(None)  

            self.matriz.append(fila)


    def generar_mapa(self):
        for f in range(self.filas):
            for c in range(self.columnas):

                if (f == 0 and c == 0) or (f == self.filas - 1 and c == self.columnas - 1):
                    self.matriz[f][c] = Camino()
                    continue

                opcion = random.randint(1, 4)

                if opcion == 1:
                    self.matriz[f][c] = Camino()
                elif opcion == 2:
                    self.matriz[f][c] = Muro()
                elif opcion == 3:
                    self.matriz[f][c] = Tunel()
                else:
                    self.matriz[f][c] = Liana()

    def obtener_casilla(self, x, y):
        #Devuelve el objeto terreno en esa COORDENADA/posicion.
        if 0 <= y < self.filas and 0 <= x < self.columnas:
            return self.matriz[y][x]
        return None

    def es_camino_valido_para_jugador(self, x, y):
        #Devuelve True si el jugador puede entrar en esa casilla.
        casilla = self.obtener_casilla(x, y)
        if casilla is None:
            return False
        return not casilla.bloquea_jugador

    def es_camino_valido_para_enemigo(self, x, y):
        #Devuelve True si un cazador puede entrar en esa casilla.
        casilla = self.obtener_casilla(x, y)
        if casilla is None:
            return False
        return not casilla.bloquea_enemigo

    def mostrar_mapa(self):
        #Imprime el mapa en texto (para revision) #puede quitarse
        for fila in self.matriz:
            print(" ".join(t.nombre[0].upper() for t in fila))
