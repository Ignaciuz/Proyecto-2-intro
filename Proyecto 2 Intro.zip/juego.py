import tkinter as tk
from tkinter import messagebox

from mapa import Mapa
from terreno import Salida
from gui import mostrar_pantalla_final
from gui import crear_interfaz_juego

from PIL import Image, ImageTk

import time
import random


#________________________________________________________________________
class Enemigo:
    def __init__(self, enemigo_y, enemigo_x):
        #misma convención que el jugador: (x,columna) — (y,fila)
        self.enemigo_x = enemigo_x
        self.enemigo_y = enemigo_y

    def mover(self, mov_y, mov_x, mapa):
        nueva_y = self.enemigo_y + mov_y
        nueva_x = self.enemigo_x + mov_x

        #límites
        if 0 <= nueva_y < mapa.filas and 0 <= nueva_x < mapa.columnas:

            terreno_destino = mapa.matriz[nueva_y][nueva_x]

            #misma lógica: permite cazador = enemigo puede pasar
            if not terreno_destino.bloquea_enemigo:
                self.enemigo_y = nueva_y
                self.enemigo_x = nueva_x
                return True

        return False

    def mover_aleatorio(self, mapa):
        movimientos = [(1,0),(-1,0),(0,1),(0,-1)]
        random.shuffle(movimientos)

        for dy, dx in movimientos:
            if self.mover(dy, dx, mapa):
                return True
        return False

    def perseguir(self, jugador, mapa):
        movimientos = []

        #Diferencias
        dy = jugador.jugador_y - self.enemigo_y
        dx = jugador.jugador_x - self.enemigo_x

        #Elegir el eje principal (el que está más lejos)
        if abs(dy) > abs(dx):
            #primero vertical
            if dy < 0: movimientos.append((-1, 0))
            elif dy > 0: movimientos.append((1, 0))

            #luego horizontal
            if dx < 0: movimientos.append((0, -1))
            elif dx > 0: movimientos.append((0, 1))
        else:
            #primero horizontal
            if dx < 0: movimientos.append((0, -1))
            elif dx > 0: movimientos.append((0, 1))

            #luego vertical
            if dy < 0: movimientos.append((-1, 0))
            elif dy > 0: movimientos.append((1, 0))

        #Intentar movimientos calculados en orden
        for mov_y, mov_x in movimientos:
            if self.mover(mov_y, mov_x, mapa):
                return True

        #Último recurso: movimiento aleatorio
        return self.mover_aleatorio(mapa)


    def huir(self, jugador, mapa):
        dy = 0
        if jugador.jugador_y < self.enemigo_y:
            dy = 1
        elif jugador.jugador_y > self.enemigo_y:
            dy = -1

        if self.mover(dy, 0, mapa):
            return True

        dx = 0
        if jugador.jugador_x < self.enemigo_x:
            dx = 1
        elif jugador.jugador_x > self.enemigo_x:
            dx = -1

        if self.mover(0, dx, mapa):
            return True

        return self.mover_aleatorio(mapa)

    def ir_a_salida(self, mapa): #Encontrar posición de la salida en el mapa
        salida = None
        for y in range(mapa.filas):
            for x in range(mapa.columnas):
                if isinstance(mapa.matriz[y][x], Salida):
                    salida = (x, y)
                    break
            if salida:
                break

        if salida is None:
            return False  #no hay salida (no debería pasar)

        salida_x, salida_y = salida

        movimientos = []
        
        dy = salida_y - self.enemigo_y
        dx = salida_x - self.enemigo_x

        if abs(dy) > abs(dx):
            if dy < 0: movimientos.append((-1, 0))
            elif dy > 0: movimientos.append((1, 0))
            if dx < 0: movimientos.append((0, -1))
            elif dx > 0: movimientos.append((0, 1))
        else:
            if dx < 0: movimientos.append((0, -1))
            elif dx > 0: movimientos.append((0, 1))
            if dy < 0: movimientos.append((-1, 0))
            elif dy > 0: movimientos.append((1, 0))

        for mov_y, mov_x in movimientos:
            if self.mover(mov_y, mov_x, mapa):
                return True

        return self.mover_aleatorio(mapa)
#________________________________________________________________________    
class Juego:
    def __init__(self, modo):
        self.modo = modo
        self.energia = 100
        self.energia_max = 100
        self.corriendo = False
        self.juego_terminado = False

        self.trampas = []
        self.max_trampas = 3
        self.trampa_disponible = True

        self.inicio_tiempo = time.time()
        self.puntaje = 0
        self.trampas_colocadas = 0
        self.enemigos_eliminados = 0
        self.enemigos_escapados = 0
        self.max_enemigos = 10

        print("Modo seleccionado:", self.modo)

        #interfaz
        (self.ventana, self.canvas, self.canvas_barra, self.barra_energia) = crear_interfaz_juego(self)

        #tamaño de celdas
        self.tam = 60  


        #muro
        self.img_muro_raw = Image.open("muro.png").resize((self.tam, self.tam))
        self.img_muro = ImageTk.PhotoImage(self.img_muro_raw)

        #liana
        self.img_liana_raw = Image.open("liana.png").resize((self.tam, self.tam))
        self.img_liana = ImageTk.PhotoImage(self.img_liana_raw)

        #tunel
        self.img_tunel_raw = Image.open("tunel.png").resize((self.tam, self.tam))
        self.img_tunel = ImageTk.PhotoImage(self.img_tunel_raw)

        #camino
        self.img_camino_raw = Image.open("camino.png").resize((self.tam, self.tam))
        self.img_camino = ImageTk.PhotoImage(self.img_camino_raw)

        #mapa
        self.mapa = Mapa(10, 10)
        self.mapa.generar_mapa()

        #enemigos
        self.enemigos = [Enemigo(5, 5), Enemigo(8, 2)]

        #jugador
        self.jugador_x = 0
        self.jugador_y = 0

        #dibujar elementos
        self.dibujar_mapa()
        self.dibujar_jugador()
        self.dibujar_enemigos()

        #controles
        self.ventana.bind("<Up>", self.arriba)
        self.ventana.bind("<Down>", self.abajo)
        self.ventana.bind("<Left>", self.izquierda)
        self.ventana.bind("<Right>", self.derecha)

        self.ventana.bind("<KeyPress-Shift_L>", self.iniciar_correr)
        self.ventana.bind("<KeyRelease-Shift_L>", self.detener_correr)

        self.ventana.bind("<e>", self.colocar_trampa)

        #energía automática
        self.recuperar_energia()

        #movimiento enemigos
        self.actualizar_enemigos()

        self.ventana.mainloop()
#_____________________________________________________________________________
        
    #DIBUJAR MAPA COMPLETO
    def dibujar_mapa(self):
        for f in range(self.mapa.filas):
            for c in range(self.mapa.columnas):

                celda = self.mapa.matriz[f][c]
                x1 = c * self.tam
                y1 = f * self.tam

                if celda.nombre == "muro":
                    self.canvas.create_image(x1, y1, image=self.img_muro, anchor="nw")

                elif celda.nombre == "liana":
                    self.canvas.create_image(x1, y1, image=self.img_liana, anchor="nw")

                elif celda.nombre == "tunel":
                    self.canvas.create_image(x1, y1, image=self.img_tunel, anchor="nw")
                    
                elif celda.nombre == "camino":
                    self.canvas.create_image(x1, y1, image=self.img_camino, anchor="nw")

                else:
                    self.canvas.create_rectangle(
                        x1, y1,
                        x1 + self.tam, y1 + self.tam,
                        fill=celda.color,
                        outline="gray"
                    )
        
    #DIBUJAR JUGADOR
    def dibujar_jugador(self):
        self.canvas.delete("jugador")

        x1 = self.jugador_x * self.tam + 10
        y1 = self.jugador_y * self.tam + 10
        x2 = x1 + self.tam - 20
        y2 = y1 + self.tam - 20

        self.canvas.create_oval(x1, y1, x2, y2, fill="#3498db", tags="jugador")

    #DIBUJAR ENEMIGO
    def dibujar_enemigos(self):
        if self.juego_terminado or not self.canvas.winfo_exists():
            return
        
        self.canvas.delete("enemigo")

        for ene in self.enemigos:
            x1 = ene.enemigo_x * self.tam + 10
            y1 = ene.enemigo_y * self.tam + 10
            x2 = x1 + self.tam - 20
            y2 = y1 + self.tam - 20

            self.canvas.create_oval(x1, y1, x2, y2,fill="red",tags="enemigo")
            
    #DIBUJAR TRAMPAS
    def dibujar_trampas(self):
        self.canvas.delete("trampa")
        for (tx, ty) in self.trampas:
            x1 = tx * self.tam + 20
            y1 = ty * self.tam + 20
            x2 = x1 + self.tam - 40
            y2 = y1 + self.tam - 40
            self.canvas.create_rectangle(x1, y1, x2, y2, fill="black", tags="trampa")
#_________________________________________________________________________
        
    #MOVIMIENTO
        #Validacion del movimiento segun el terreno
    def puede_moverse(self, x, y):
        casilla = self.mapa.obtener_casilla(x, y)
        if casilla is None:
            return False
        else:
            return not casilla.bloquea_jugador

    
    def arriba(self, event):
        if self.puede_moverse(self.jugador_x, self.jugador_y - 1):
            if self.corriendo and self.energia > 0:
                self.jugador_y -= 2
                self.energia -= 5
            else:
                self.jugador_y -= 1
            self.dibujar_jugador()
            self.verificar_salida()
            self.actualizar_barra_energia()

    def abajo(self, event):
        if self.puede_moverse(self.jugador_x, self.jugador_y + 1):
            if self.corriendo and self.energia > 0:
                self.jugador_y += 2
                self.energia -= 5
            else:
                self.jugador_y += 1
            self.dibujar_jugador()
            self.verificar_salida()
            self.actualizar_barra_energia()

    def izquierda(self, event):
        if self.puede_moverse(self.jugador_x - 1, self.jugador_y):
            if self.corriendo and self.energia > 0:
                self.jugador_x -= 2
                self.energia -= 5
            else:
                self.jugador_x -= 1
            self.dibujar_jugador()
            self.verificar_salida()
            self.actualizar_barra_energia()

    def derecha(self, event):
        if self.puede_moverse(self.jugador_x + 1, self.jugador_y):
            if self.corriendo and self.energia > 0:
                self.jugador_x += 2
                self.energia -= 5
            else:
                self.jugador_x += 1
            self.dibujar_jugador()
            self.verificar_salida()
            self.actualizar_barra_energia()

#_________________________________________________________________________

    def colocar_trampa(self, event=None):
        if self.modo.lower() != "escapa":
            return

        #maximo de trampas activas
        if len(self.trampas) >= self.max_trampas:
            messagebox.showwarning("Límite", "Solo puedes tener 3 trampas activas.")
            return

        #cooldown
        if not self.trampa_disponible:
            messagebox.showwarning("Cooldown", "Debes esperar 5 segundos para colocar otra trampa.")
            return

        posicion = (self.jugador_x, self.jugador_y)

        #evitar poner 2 trampas en una misma casilla
        if posicion in self.trampas:
            return

        self.trampas.append(posicion)
        self.dibujar_trampas()

        self.trampa_disponible = False
        self.ventana.after(5000, self.reiniciar_trampa)
        self.trampas_colocadas += 1


    def reiniciar_trampa(self):
        self.trampa_disponible = True
#_________________________________________________________________________
    def actualizar_barra_energia(self):
        if self.juego_terminado:
            return
        
        porcentaje = self.energia / self.energia_max
        ancho = 200 * porcentaje  #barra completa es 200pix

        self.canvas_barra.coords(self.barra_energia, 0, 0, ancho, 20)

        if porcentaje > 0.6:
            color = "green"
        elif porcentaje > 0.3:
            color = "yellow"
        else:
            color = "red"

        self.canvas_barra.itemconfig(self.barra_energia, fill=color)


    def iniciar_correr(self, event):
        self.corriendo = True

    def detener_correr(self, event):
        self.corriendo = False

    def recuperar_energia(self):
        if self.juego_terminado:
            return
    
        if not self.corriendo and self.energia < self.energia_max:
            self.energia += 1

        self.actualizar_barra_energia()
        self.ventana.after(500, self.recuperar_energia)

#_______________________________________________________________________________
    def actualizar_enemigos(self):
        #caso base para detener a los enemigos cuando se gana
        if self.juego_terminado or not self.canvas.winfo_exists():
            return

        #se hace una copia porque vamos a eliminar enemigos dentro del ciclo
        for ene in self.enemigos[:]:

            #movimiento según el modo de juego
            if self.modo.lower() == "escapa":
                move = ene.perseguir(self, self.mapa)
                
            elif self.modo.lower() == "cazador":
                move = ene.ir_a_salida(self.mapa)
                
            else:
                move = ene.huir(self, self.mapa)

            #Si el enemigo no pudo moverse 
            if not move:
                #Respawn automático del enemigo atascado 
                self.enemigos.remove(ene)
                self.ventana.after(2000, self.respawn_cazador)
                continue

            #Si el enemigo cae en una trampa
            if (ene.enemigo_x, ene.enemigo_y) in self.trampas:
                #borrar trampa
                self.trampas.remove((ene.enemigo_x, ene.enemigo_y))
                self.dibujar_trampas()
                #eliminar enemigo
                self.enemigos.remove(ene)
                #respawn en 10s
                self.ventana.after(10000, self.reaparecer_enemigo)
                self.enemigos_eliminados += 1
                continue

            #colisión entre enemigo y jugador
            if ene.enemigo_x == self.jugador_x and ene.enemigo_y == self.jugador_y:

                #modo cazador
                if self.modo.lower() == "cazador":
                    self.enemigos.remove(ene)
                    self.enemigos_eliminados += 1   
                    self.verificar_fin_cazador()

                    #respawn después de 3 segundos
                    self.ventana.after(3000, self.respawn_cazador)
                    continue

                #modo escapa
                else:
                    messagebox.showerror("¡Te atraparon!", "Un enemigo te atrapó.")
                    self.ventana.destroy()
                    return

            #MODO CAZADOR: enemigo llegó a la salida
            celda = self.mapa.obtener_casilla(ene.enemigo_x, ene.enemigo_y)
            if isinstance(celda, Salida) and self.modo.lower() == "cazador":
                self.enemigos_escapados += 1

                messagebox.showwarning(
                    "Un cazador escapó.",
                    f"Un enemigo logró llegar a la salida.\n Escapados: {self.enemigos_escapados}")
                # Verificar fin del juego
                self.verificar_fin_cazador()

                #Respawn del enemigo
                self.enemigos.remove(ene)
                self.ventana.after(3000, self.respawn_cazador)
                continue

        #REDIBUJAR Y PROGRAMAR SIGUIENTE CICLO
        self.dibujar_enemigos()
        self.ventana.after(400, self.actualizar_enemigos)


    def reaparecer_enemigo(self):
        #Los enemigos reaparecen siempre en la misma casilla por ahora.
        nuevo = Enemigo(0, 0)
        self.enemigos.append(nuevo)
        self.dibujar_enemigos()
        
    def respawn_cazador(self):
        while True:
            x = random.randint(0, self.mapa.columnas - 1)  # cualquier columna
            y = 0  #spawn en primera fila 

            casilla = self.mapa.matriz[y][x]

            if not casilla.bloquea_enemigo and (x, y) != (self.jugador_x, self.jugador_y):
                self.enemigos.append(Enemigo(y, x))
                self.dibujar_enemigos()
                return
#_______________________________________________________________________________

    def verificar_salida(self):
        celda = self.mapa.obtener_casilla(self.jugador_x, self.jugador_y)

        if self.modo.lower() == "cazador":
            return
        
        elif isinstance(celda, Salida):
            self.juego_terminado = True


            tiempo_total = time.time() - self.inicio_tiempo
            puntaje_tiempo = max(0, int(500 - tiempo_total * 10))
            self.puntaje += puntaje_tiempo

            messagebox.showinfo("¡Ganaste!",f"Llegaste a la salida.\n\nPuntaje final: {self.puntaje}")

            #cerrar ventana de juego
            self.ventana.destroy()

            #btener estadísticas
            stats = self.obtener_estadisticas_finales()

            #abrir GUI final
            mostrar_pantalla_final(stats)

    def verificar_fin_cazador(self):
        total = self.enemigos_eliminados + self.enemigos_escapados

        if total >= self.max_enemigos:
            self.juego_terminado = True

            mensaje = (
                f"Juego terminado.\n\n Enemigos cazados: {self.enemigos_eliminados}\n Enemigos escapados: {self.enemigos_escapados}\n Total: {total}/{self.max_enemigos}")

            messagebox.showinfo("Fin del modo Cazador", mensaje)
            
            self.ventana.destroy()

            stats = self.obtener_estadisticas_finales()
            mostrar_pantalla_final(stats)
#_______________________________________________________________

    def obtener_estadisticas_finales(self):
        tiempo_total = round(time.time() - self.inicio_tiempo, 2)

        # MODO ESCAPA
        if self.modo.lower() == "escapa":
            estadisticas = {"Modo": self.modo,"Puntaje": self.puntaje,"Tiempo": tiempo_total,"Trampas colocadas": self.trampas_colocadas,"Enemigos eliminados": self.enemigos_eliminados  }

        # MODO CAZADOR
        else:
            estadisticas = {"Modo": self.modo,"Tiempo": tiempo_total,"Enemigos cazados": self.enemigos_eliminados,"Enemigos escapados": self.enemigos_escapados,"Total procesados": self.enemigos_eliminados + self.enemigos_escapados,"Objetivo": self.max_enemigos}

        return estadisticas
    
    
    
