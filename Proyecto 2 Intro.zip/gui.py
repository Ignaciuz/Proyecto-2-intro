import tkinter as tk
from tkinter import messagebox

#________________________________________________________________________________________________________________________

def mostrar_pantalla_final(stats):

    ventana_final = tk.Tk()
    ventana_final.title("Resumen de la Partida")
    ventana_final.geometry("420x420")
    ventana_final.resizable(False, False)

    frame = tk.Frame(ventana_final, bg="#f0f0f0")
    frame.pack(fill="both", expand=True)

    lbl_titulo = tk.Label(frame,text="RESUMEN DE LA PARTIDA",font=("Arial", 18, "bold"),bg="#f0f0f0")
    lbl_titulo.pack(pady=15)

    modo = stats.get("Modo", "").lower()
    # mostrar estadísticas
    if modo == "escapa":
        lista_mostrar = [("Puntaje", stats.get("Puntaje", 0)),
            ("Tiempo", stats.get("Tiempo", "0")),
            ("Enemigos eliminados", stats.get("Enemigos eliminados", 0)),
            ("Trampas colocadas", stats.get("Trampas colocadas", 0))]

    elif modo == "cazador":
        lista_mostrar = [
            ("Puntaje", stats.get("Puntaje", 0)),
            ("Tiempo", stats.get("Tiempo", "0")),
            ("Enemigos cazados", stats.get("Enemigos cazados", 0)),
            ("Enemigos escapados", stats.get("Enemigos escapados", 0))]

    for texto, valor in lista_mostrar:
        lbl = tk.Label(frame, text=f"{texto}: {valor}",
                       font=("Arial", 14), bg="#f0f0f0")
        lbl.pack(pady=5)
    
    # nombre del jugador
    lbl_nombre = tk.Label(frame,text="Ingrese su nombre:",font=("Arial", 14),bg="#f0f0f0")
    lbl_nombre.pack(pady=10)

    entrada_nombre = tk.Entry(frame, font=("Arial", 14), width=25)
    entrada_nombre.pack(pady=5)

    def guardar():
        nombre = entrada_nombre.get().strip()
        if nombre == "":
            messagebox.showerror("Error", "Debe ingresar un nombre.")
            return

        # Construir la línea dependiendo del modo
        if modo == "escapa":linea = f"{nombre},{stats['Modo']},{stats.get('Puntaje', 0)},{stats.get('Tiempo','0')},{stats.get('Enemigos eliminados',0)},{stats.get('Trampas colocadas',0)}\n"

        elif modo == "cazador":linea = f"{nombre},{stats['Modo']},{stats.get('Puntaje',0)},{stats.get('Tiempo','0')},{stats.get('Enemigos atrapados',0)},{stats.get('Enemigos escapados',0)}\n"


        # Guardar en archivo
        with open("puntajes.txt", "a", encoding="utf-8") as f:
            f.write(linea)

        messagebox.showinfo("Guardado", "Puntaje guardado.")
        ventana_final.destroy()

    btn_guardar = tk.Button(frame, text="Guardar Puntaje",font=("Arial", 14), command=guardar)
    btn_guardar.pack(pady=15)

    btn_salir = tk.Button(frame, text="Salir",font=("Arial", 14),command=ventana_final.destroy)
    btn_salir.pack(pady=10)

#________________________________________________________________________________________________________________________


def crear_interfaz_juego(juego):

    #rear ventana principal
    ventana = tk.Tk()

    #Forzar foco (soluciona el problema de tener que hacer click primero)
    ventana.focus_force()
    ventana.attributes('-topmost', True)

    ventana.title("Escapa del Laberinto")
    ventana.geometry("700x700")
    ventana.configure(bg="#f0f4f8")

    #HUD
    frame_hud = tk.Frame(ventana, bg="#f0f4f8")
    frame_hud.pack(pady=10)

    label_energia = tk.Label(frame_hud, text="Energía:", font=("Helvetica", 12), bg="#f0f4f8")
    label_energia.pack(side="left", padx=5)

    #Barra de energía
    canvas_barra = tk.Canvas(frame_hud, width=200, height=20, bg="lightgray", highlightthickness=0)
    canvas_barra.pack(side="left")

    barra_energia = canvas_barra.create_rectangle(0, 0, 200, 20, fill="green")

    #Canvas principal donde se dibuja el mapa
    canvas = tk.Canvas(ventana, width=600, height=600, bg="white")
    canvas.pack()

    return ventana, canvas, canvas_barra, barra_energia

